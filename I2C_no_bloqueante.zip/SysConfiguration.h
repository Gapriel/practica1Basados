/*
 * SysConfiguration.h
 *
 *  Created on: Mar 5, 2018
 *      Author: gabrielpc
 */

#ifndef SYSCONFIGURATION_H_
#define SYSCONFIGURATION_H_

void SystemConfiguration(void* args);

#endif /* SYSCONFIGURATION_H_ */
